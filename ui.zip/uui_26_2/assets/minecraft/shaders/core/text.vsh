#version 330
#define UNREL_ID

#define MAP_DEPTH 1.0
#define MARKER_DEPTH 1.0

#ifdef GL_ARB_shader_draw_parameters
#extension GL_ARB_shader_draw_parameters : require
#endif

#moj_import <nminimap:config.glsl>

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:sample_lightmap.glsl>
#endif

#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:globals.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
uniform sampler2D Sampler0;
#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
in ivec2 UV2;
uniform sampler2D Sampler2;
out float sphericalVertexDistance;
out float cylindricalVertexDistance;
#endif

out vec4 vertexColor;
out vec2 texCoord0;

flat out int custom;
out vec2 uvCoord;

// hud.glsl uses the global `Position`, so import it AFTER `in vec3 Position;` is declared.
#moj_import <hud.glsl>
#moj_import <nminimap:vertex_utils.glsl>

void main() {
    // NMinimap outputs (default = normal text, so UI/normal text renders untouched)
    custom = 0;
    uvCoord = vec2(0);

    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);
    texCoord0 = UV0;

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);
    vertexColor = Color * sample_lightmap(Sampler2, UV2);

    // NMinimap: claims map/marker glyphs (magic pixel colours), sets custom/uvCoord + gl_Position.
    #moj_import <nminimap:vertex_body.glsl>
#else
    vertexColor = Color;
#endif

    // UltimateUI: repositions its HUD glyphs (Position.y < -1000). Only runs for glyphs NMinimap
    // did NOT claim, so the two never fight over the same glyph.
    if (custom == 0 && make_hud()) {
        vertexColor = Color;
#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
        sphericalVertexDistance = 0.0;
        cylindricalVertexDistance = 0.0;
#endif
    }
}
