// McWarsHUD (MCWARS' own HUD). Moves HUD glyphs from the hidden bossbar line to their place on screen.
// The plugin draws every HUD element into a band far below the screen (3000 GUI px per band):
// band 1 = left-anchored, 2 = centre-anchored, 3 = right-anchored. Inside a band, x is measured from the screen
// centre and y from band start + 100, both in half-pixels of a 1920x1080 canvas scaled with the GUI scale.
if (custom == 0 && ProjMat[3][3] == 1.0 && Position.y >= 3000.0 && Position.y < 12000.0) {
    float hudBand = floor(Position.y / 3000.0);
    float hudGuiW = floor(2.0 / ProjMat[0][0] + 0.5);
    vec2 hudCanvas = vec2(Position.x - floor(hudGuiW / 2.0), Position.y - hudBand * 3000.0 - 100.0) * 2.0;
    // follows the player's GUI scale like the vanilla HUD: at GUI scale 4 one canvas px = one screen px
    float hudK = floor(ScreenSize.x / hudGuiW + 0.5) / 4.0;
    float hudBaseX = hudBand < 1.5 ? 0.0 : (hudBand < 2.5 ? ScreenSize.x * 0.5 - 960.0 * hudK : ScreenSize.x - 1920.0 * hudK);
    vec2 hudPx = vec2(hudBaseX + hudCanvas.x * hudK, hudCanvas.y * hudK);
    gl_Position = vec4(hudPx.x / ScreenSize.x * 2.0 - 1.0, 1.0 - hudPx.y / ScreenSize.y * 2.0, gl_Position.z, 1.0);
    sphericalVertexDistance = 0.0;
    cylindricalVertexDistance = 0.0;
}
