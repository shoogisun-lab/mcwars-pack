#define HUD_HEAD_COUNT 3
const vec4 HUD_HEADS[3] = vec4[](vec4(33.0, 32.0, 54.0, 1.0), vec4(33.0, 192.0, 54.0, 1.0), vec4(33.0, 352.0, 54.0, 1.0));
// McWarsHUD (MCWARS' own HUD). Moves HUD glyphs from the hidden bossbar line to their place on screen.
// The plugin draws every HUD element into a band far below the screen (3000 GUI px per band):
// band 1 = left-anchored, 2 = centre-anchored, 3 = right-anchored. Inside a band, x is measured from the screen
// centre and y from band start + 100, both in half-pixels of a 1920x1080 canvas scaled to the window height (GUI scale doesn't change it).
if (custom == 0 && ProjMat[3][3] == 1.0 && Position.y >= 3000.0 && Position.y < 12000.0) {
    float hudBand = floor(Position.y / 3000.0);
    float hudGuiW = floor(2.0 / ProjMat[0][0] + 0.5);
    vec2 hudCanvas = vec2(Position.x - floor(hudGuiW / 2.0), Position.y - hudBand * 3000.0 - 100.0) * 2.0;
    // same size at every GUI scale: the 1920x1080 canvas is scaled to the window height
    float hudK = ScreenSize.y / 1080.0;
    float hudBaseX = hudBand < 1.5 ? 0.0 : (hudBand < 2.5 ? ScreenSize.x * 0.5 - 960.0 * hudK : ScreenSize.x - 1920.0 * hudK);
    vec2 hudPx = vec2(hudBaseX + hudCanvas.x * hudK, hudCanvas.y * hudK);
    gl_Position = vec4(hudPx.x / ScreenSize.x * 2.0 - 1.0, 1.0 - hudPx.y / ScreenSize.y * 2.0, gl_Position.z, 1.0);
    sphericalVertexDistance = 0.0;
    cylindricalVertexDistance = 0.0;
}

// Player heads (skin faces) on the HUD cards. A head can't be pushed into a band like text (its size and height
// are fixed), so the plugin puts head number i at x = centre + 1500 + 32*i on the bossbar line; this finds the
// 64x64 skin texture there and moves the face to that card's slot (canvas x, y, size, band) listed below.
#ifdef HUD_HEAD_COUNT
if (custom == 0 && ProjMat[3][3] == 1.0 && Position.y > 1.0 && Position.y < 12.0 && textureSize(Sampler0, 0) == ivec2(64, 64)) {
    float hudHGuiW = floor(2.0 / ProjMat[0][0] + 0.5);
    float hudRel = Position.x - floor(hudHGuiW / 2.0) - 1500.0;
    int hudSlot = int(floor((hudRel + 4.0) / 32.0));
    if (hudRel > -2.0 && hudSlot >= 0 && hudSlot < HUD_HEAD_COUNT) {
        vec4 hudHs = HUD_HEADS[hudSlot];
        vec2 hudLocal = clamp(vec2(hudRel - float(hudSlot) * 32.0, Position.y - 2.0) / 8.0, 0.0, 1.0);
        vec2 hudCanvasH = hudHs.xy + hudLocal * hudHs.z;
        float hudKH = ScreenSize.y / 1080.0;
        float hudBaseXH = hudHs.w < 1.5 ? 0.0 : (hudHs.w < 2.5 ? ScreenSize.x * 0.5 - 960.0 * hudKH : ScreenSize.x - 1920.0 * hudKH);
        vec2 hudPxH = vec2(hudBaseXH + hudCanvasH.x * hudKH, hudCanvasH.y * hudKH);
        gl_Position = vec4(hudPxH.x / ScreenSize.x * 2.0 - 1.0, 1.0 - hudPxH.y / ScreenSize.y * 2.0, gl_Position.z, 1.0);
        sphericalVertexDistance = 0.0;
        cylindricalVertexDistance = 0.0;
    }
}
#endif

// McWarsHUD animations (e.g. the game-start transition). Every animation glyph sits at GUI y 20480 on the HUD line
// and its x on the line says where it goes: x = slot * 2048 + local (GUI px from the line start), where
// slot = 1 + anchor * 1280 + (canvas y + 128) and canvas x = 2 * local relative to the anchor (left edge, centre or
// right edge of the window). The colour's high 6 bits per channel are the colour, the low 2 bits a 6-bit opacity.
if (custom == 0 && ProjMat[3][3] == 1.0 && Position.y >= 20352.0 && Position.y < 28672.0) {
    float hudAGuiW = floor(2.0 / ProjMat[0][0] + 0.5);
    float hudARel = Position.x - floor(hudAGuiW / 2.0);
    float hudASlot = floor((hudARel + 1024.0) / 2048.0);
    if (hudASlot >= 1.0 && hudASlot <= 3840.0) {
        float hudALocal = hudARel - hudASlot * 2048.0;
        float hudAS = hudASlot - 1.0;
        float hudAAnchor = floor(hudAS / 1280.0);
        float hudAShift = hudAAnchor < 0.5 ? -960.0 : (hudAAnchor < 1.5 ? 0.0 : 960.0);
        vec2 hudACanvas = vec2(hudALocal * 2.0 - hudAShift,
            hudAS - hudAAnchor * 1280.0 - 128.0 + (Position.y - 20480.0) * 2.0);
        float hudAK = ScreenSize.y / 1080.0;
        float hudAOrigin = hudAAnchor < 0.5 ? 0.0 : (hudAAnchor < 1.5 ? ScreenSize.x * 0.5 : ScreenSize.x);
        vec2 hudAPx = floor(vec2(hudAOrigin + hudACanvas.x * hudAK, hudACanvas.y * hudAK) + 0.5);
        gl_Position = vec4(hudAPx.x / ScreenSize.x * 2.0 - 1.0, 1.0 - hudAPx.y / ScreenSize.y * 2.0, gl_Position.z, 1.0);
        ivec3 hudAC = ivec3(round(Color.rgb * 255.0));
        int hudAOp = ((hudAC.r & 3) << 4) | ((hudAC.g & 3) << 2) | (hudAC.b & 3);
        vertexColor = vec4(vec3(hudAC & ivec3(252)) / 252.0, Color.a * float(hudAOp) / 63.0);
        sphericalVertexDistance = 0.0;
        cylindricalVertexDistance = 0.0;
    }
}
