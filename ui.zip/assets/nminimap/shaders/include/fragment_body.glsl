// White outline: paint the outer ring of the map white BEFORE the out-of-bounds discard.
// Square map (custom==1): a 2px border on all four edges. Round map (custom==2): a 2px ring.
if (custom == 1 && (uvCoord.x < 3.0 || uvCoord.y < 3.0 || uvCoord.x > MAP_CONTENT_SIZE - 2.0 || uvCoord.y > MAP_CONTENT_SIZE - 2.0))
    color = vec4(1.0, 1.0, 1.0, 1.0);
if (custom == 2 && length(uvCoord - 1.0 - MAP_CROP_RADIUS) > MAP_CROP_RADIUS - 2.0)
    color = vec4(1.0, 1.0, 1.0, 1.0);

if (
    (custom == 1 && (uvCoord.x < 1.0 || uvCoord.y < 1.0 || uvCoord.x > MAP_CONTENT_SIZE || uvCoord.y > MAP_CONTENT_SIZE)) ||
    (custom == 2 && length(uvCoord - 1 - MAP_CROP_RADIUS) > MAP_CROP_RADIUS)
)
    discard;
