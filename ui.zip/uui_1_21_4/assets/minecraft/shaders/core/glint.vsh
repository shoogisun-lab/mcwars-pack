#version 150

#moj_import <minecraft:fog.glsl>

in vec3 Position;
in vec2 UV0;

uniform mat4 ModelViewMat;
uniform mat4 ProjMat;
uniform mat4 TextureMat;
uniform int FogShape;
uniform vec2 ScreenSize;

out float vertexDistance;
out vec2 texCoord0;

#moj_import <hud.glsl>

void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);

    vertexDistance = fog_distance(Position, FogShape);
    texCoord0 = (TextureMat * vec4(UV0, 0.0, 1.0)).xy;

    if (make_hud()) {
        vertexDistance = 0.0;
    }
}